# FindSafe

FindSafe is a college-project prototype for analyzing **authorized CCTV footage**
for possible sightings of a missing person.

## What it does

1. Takes a reference image.
2. Takes an authorized CCTV video.
3. Detects people using YOLO.
4. Computes a simple HSV color-histogram similarity between the reference image
   and detected person crops.
5. Saves candidate frames above a configurable threshold.
6. Displays camera, location, timestamp and similarity score on a dashboard.

## Important limitation

This is NOT a facial-recognition or identity-verification system.

The similarity score can produce false positives and false negatives. It should
only be treated as a candidate-generation signal, followed by human verification.

## Run

Use Python 3.10+.

```bash
python -m venv .venv
```

Windows:

```bash
.venv\Scripts\activate
```

Install:

```bash
pip install -r requirements.txt
```

Start:

```bash
uvicorn app:app --reload
```

Open:

http://127.0.0.1:8000

The first run downloads the YOLO model automatically.

## Suggested future modules

- PostgreSQL database for cases and audit logs
- JWT authentication
- Role-based access control
- AES-encrypted evidence storage
- Camera registration and authorization
- Automatic retention/deletion policy
- Multi-camera timeline
- Better person re-identification model
- Human verification workflow
- Tamper-evident audit logs
- Alert integration for authorized responders

## Project architecture

Browser
  -> FastAPI
      -> CCTV upload
      -> YOLO person detector
      -> Appearance similarity
      -> Candidate evidence
      -> Dashboard

For a real deployment, integrate only with cameras and organizations for which
you have explicit authorization and follow applicable privacy/data-protection law.
